
import SwiftUI

public struct PredictionRow: View {
    
    public var title: String 
    public var backgroundColor: Color
    @Binding public var value: String
    
    public init(title: String, value: Binding<String>, backgroundColor: Color) {
        self.title = title
        self._value = value
        self.backgroundColor = backgroundColor
    }
    
    public var body: some View {
        ZStack { 
            RoundedRectangle(cornerRadius: 18)
                .foregroundColor(backgroundColor)
                .frame(width: 120, height: 120)
            
            VStack(spacing: 15) {
                Text(title)
                    .foregroundColor(.white)
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .multilineTextAlignment(.leading)
                Text(value)
                    .foregroundColor(.white)
                    .font(.system(size: 35,
                                  weight: .bold,
                                  design: .rounded))
            }
        }
    }
}
