
import Foundation 

public enum CloudCover: Double {
    case cloudy = 0.15
    case rain = 0.5
    case storm = 0.8
    
    static func symbol(value: Double) -> String {
        switch value {
        case 0.0..<0.45: return "􀇃"
        case 0.45..<0.65: return "􀇇"
        case 0.65..<1.0: return "􀇟"
        default: return ""
        }
    }
}

public enum WindDirection: Double {
    case north = 45
    case west = 135
    case south = 225
    case east = 315
    
    static func symbol(angle: Double) -> String {
        switch angle {
            case 0..<90: return "􀄨"
            case 90..<180: return "􀄪"
            case 180..<270: return "􀄩"
            case 270..<360: return "􀄫"
        default: return ""
        }
    }
}

public enum Humidity: Double {
    case min = 0.15
    case normal = 0.5
    case max = 0.8
}
