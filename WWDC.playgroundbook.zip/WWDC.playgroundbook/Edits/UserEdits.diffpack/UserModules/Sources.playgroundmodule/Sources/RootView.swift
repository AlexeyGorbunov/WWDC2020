import SwiftUI

public struct RootView: View {
    
    public init() { }
    
    public var body: some View {
        GeometryReader { (reader) in
            VStack {
                MapView()
                    .frame(minHeight: reader.size.height/2)
                
                PredictionView()
                    .frame(height: 150.0)
                    .offset(y: -35)
                
                ConfigurationView()
                    .frame(height: 350)
            }
        }
    }
}
