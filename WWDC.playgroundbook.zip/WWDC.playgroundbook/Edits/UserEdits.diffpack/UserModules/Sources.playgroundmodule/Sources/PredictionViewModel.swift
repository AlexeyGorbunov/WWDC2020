
import Foundation
import Combine

public class PredictionViewModel: ObservableObject  {
    
    let weatherManager = WeatherManager.shared
    
    @Published var temperature: String = .init()
    @Published var windDirection: String = .init()
    @Published var cloudCover: String = .init()
    @Published var pressure: String = .init()
    @Published var windSpeed: String = .init()
    
    var cancellable = Set<AnyCancellable>()
    
    public init() {
        weatherManager.temperatureOutput
            .receive(on: RunLoop.main)
            .removeDuplicates()
            .assign(to: \.temperature, on: self)
            .store(in: &cancellable)
        
        weatherManager.windDirectionOutput
            .receive(on: RunLoop.main)
            .removeDuplicates()
            .assign(to: \.windDirection, on: self)
            .store(in: &cancellable)
        
        weatherManager.cloudCoverOutput
            .receive(on: RunLoop.main)
            .removeDuplicates()
            .assign(to: \.cloudCover, on: self)
            .store(in: &cancellable)
        
        weatherManager.pressureOutput
            .receive(on: RunLoop.main)
            .removeDuplicates()
            .assign(to: \.pressure, on: self)
            .store(in: &cancellable)
        
        weatherManager.windSpeedOutput
            .receive(on: RunLoop.main)
            .removeDuplicates()
            .assign(to: \.windSpeed, on: self)
            .store(in: &cancellable)
    }
}


