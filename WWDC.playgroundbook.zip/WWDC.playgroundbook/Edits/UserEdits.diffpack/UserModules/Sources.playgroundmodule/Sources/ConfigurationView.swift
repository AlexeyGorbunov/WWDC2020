
import SwiftUI
import Combine

public struct ConfigurationView: View {
    
    @ObservedObject var viewModel = ConfigurationViewModel()
    
    public init() {}
    
    public var body: some View {
        ZStack { 
            Color.black
                .cornerRadius(15)
            
            VStack(spacing: 5) {
                Text("Current Weather")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                
                Spacer()
                
                GeometryReader { (reader) in
                    VStack(spacing: 5) {
                        HStack(spacing: 5) {
                            TemperatureRow(temp: self.$viewModel.temperature)
                                .frame(width: reader.size.width/2, height: reader.size.height/2)
                            Spacer(minLength: 10)
                            WindDirectionRow(wind: self.$viewModel.windDirection)
                                .frame(width: reader.size.width/2, height: reader.size.height/2)
                        }
                        HStack(spacing: 5) {
                            CloudCoverRow(cloudCover: self.$viewModel.cloudCover)
                                .frame(width: reader.size.width/2, height: reader.size.height/2)
                            Spacer(minLength: 10)
                            HumidityRow(humidity: self.$viewModel.humidity)
                                .frame(width: reader.size.width/2, height: reader.size.height/2)
                        }
                    }
                }
                .padding()
                
                Spacer(minLength: 30)
            }
            .padding(15)
        }
    }
}
