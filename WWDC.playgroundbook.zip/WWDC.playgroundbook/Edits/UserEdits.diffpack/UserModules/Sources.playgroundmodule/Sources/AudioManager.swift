import Foundation 
import Combine
import AVFoundation

public class AudioManager {
    
    public static var shared = AudioManager()
    private var player: AVAudioPlayer?
    
    private init() { }
    
    public func play() {
        do{
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            self.player = try AVAudioPlayer(contentsOf: #fileLiteral(resourceName: "GoodVibe.mp3"), fileTypeHint: AVFileType.mp3.rawValue)
            self.player?.volume = 0.3
            self.player?.prepareToPlay()
            self.player?.play()
            self.player?.numberOfLoops = -1

            //self.loopingMusic(player: player)

        } catch {
            
        }
    }
    
    static func loopingMusic(player: AVAudioPlayer) {
        DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
            if player.isPlaying {
                self.loopingMusic(player: player)
            } else {
                return 
            }
        }
    }
}
