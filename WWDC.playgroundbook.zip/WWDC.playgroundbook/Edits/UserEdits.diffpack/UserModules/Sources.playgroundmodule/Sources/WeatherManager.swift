import Foundation
import Combine
import CoreML

public enum PredictionItemType: String {
    case temperature = "temperature"
    case windDirection = "windBearing"
    case cloudCover = "cloudCover"
    case pressure = "pressure"
    case windSpeed = "windSpeed"
}

public class WeatherManager {
    
    static public let shared = WeatherManager()
    
    public var temperatureInput = PassthroughSubject<Double, Never>()
    public var windDirectionInput = PassthroughSubject<Double, Never>()
    public var cloudCoverInput = PassthroughSubject<Double, Never>()
    public var humidityInput = PassthroughSubject<Double, Never>()
    
    public var temperatureOutput = PassthroughSubject<String, Never>()
    public var windDirectionOutput = PassthroughSubject<String, Never>()
    public var cloudCoverOutput = PassthroughSubject<String, Never>()
    public var pressureOutput = PassthroughSubject<String, Never>()
    public var windSpeedOutput = PassthroughSubject<String, Never>()
    
    var cancellable = Set<AnyCancellable>()
    
    private var calculateTempPublisher: AnyCancellable {
        Publishers
            .CombineLatest3(cloudCoverInput, humidityInput, windDirectionInput)
            .eraseToAnyPublisher()
            .sink { (cloudCoverInput, humidityInput, windDirectionInput) in
                let value = self.getPredictionItem(type: .temperature, inputs: ["cloudCover": cloudCoverInput,
                                                                               "humidity": humidityInput,
                                                                               "windBearing": windDirectionInput])
                let сelsiusTemp = Int(value - 32.0 * 1.3)
                self.temperatureOutput.send(String(сelsiusTemp) + "°C") 
        }
    }
    
    private var calculateWindDirectionPublisher: AnyCancellable {
        Publishers
            .CombineLatest3(cloudCoverInput, humidityInput, temperatureInput)
            .eraseToAnyPublisher()
            .sink { (cloudCoverInput, humidityInput, temperatureInput) in
                let value = self.getPredictionItem(type: .windDirection, inputs: ["cloudCover": cloudCoverInput,
                                                                                  "humidity": humidityInput,
                                                                                  "temperature": temperatureInput])
                let symbol = WindDirection.symbol(angle: value)
                self.windDirectionOutput.send(symbol)
        }
    }
    
    private var calculateCloudCoverPublisher: AnyCancellable {
        Publishers
            .CombineLatest3(temperatureInput, humidityInput, windDirectionInput)
            .eraseToAnyPublisher()
            .sink { (temperatureInput, humidityInput, windDirectionInput) in
                let value = self.getPredictionItem(type: .cloudCover, inputs: ["windBearing": windDirectionInput, 
                                                                               "humidity": humidityInput,
                                                                               "temperature": temperatureInput])
                let symbol = CloudCover.symbol(value: value)
                self.cloudCoverOutput.send(symbol)
        }
    }
    
    private var calculatePressurePublisher: AnyCancellable {
        Publishers
            .CombineLatest4(cloudCoverInput, humidityInput, windDirectionInput, temperatureInput)
            .eraseToAnyPublisher()
            .sink { (cloudCoverInput, humidityInput, windDirectionInput, temperatureInput) in
                let value = self.getPredictionItem(type: .pressure, inputs: ["windBearing": windDirectionInput, 
                                                                             "humidity": humidityInput,
                                                                             "temperature": temperatureInput,
                                                                             "cloudCover": cloudCoverInput])
                let pressure = Int(value - 250)
                self.pressureOutput.send(String(pressure))
        }
    }
    
    private var calculateWindSpeedPublisher: AnyCancellable {
        Publishers
            .CombineLatest4(cloudCoverInput, humidityInput, windDirectionInput, temperatureInput)
            .eraseToAnyPublisher()
            .sink { (cloudCoverInput, humidityInput, windDirectionInput, temperatureInput) in
                let value = self.getPredictionItem(type: .windSpeed, inputs: ["windBearing": windDirectionInput, 
                                                                             "humidity": humidityInput,
                                                                             "temperature": temperatureInput,
                                                                             "cloudCover": cloudCoverInput])
                let windSpeed = Int(value)
                self.windSpeedOutput.send(String(windSpeed) + " m/s")
        }
    }
    
    public init() {
        calculateTempPublisher
            .store(in: &cancellable)
        
        calculateWindDirectionPublisher
            .store(in: &cancellable)
        
        calculateCloudCoverPublisher
            .store(in: &cancellable)
        
        calculatePressurePublisher
            .store(in: &cancellable)
        
        calculateWindSpeedPublisher
            .store(in: &cancellable)
        
    }
    
    private func getOutput(featureNames: Set<String>,
                           inputs: [String: Double],
                           type: PredictionItemType,
                           outputName: String) -> Double {
        let model = PredictionModel(type: type)
        guard let prediction = try? model.prediction(featureNames: featureNames, inputs: inputs) 
            else { fatalError("Unexpected runtime error.") }
        return prediction.outputs[outputName]!
    }
    
    private func getPredictionItem(type: PredictionItemType, inputs: [String: Double]) -> Double {
        return getOutput(featureNames: [type.rawValue],
                         inputs: inputs,
                         type: type,
                         outputName: type.rawValue)
    }
}
