

import SwiftUI
import Combine

public struct PredictionView: View {
    
    @ObservedObject var viewModel = PredictionViewModel()
    
    public init() { }
    
    public var body: some View {
        ZStack { 
            Color.white
            
            VStack {
                Text("Prediction Weather")
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundColor(.black)
                    .padding(5)
                Text("The weather forecast for tomorrow")
                    .font(.system(size: 18, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
                    .padding(5)
                
                HStack(alignment: .center, spacing: 15) {
                    PredictionRow(title: "Temperature",
                                   value: self.$viewModel.temperature,
                                   backgroundColor: .orange)
                    PredictionRow(title: "Wind Direction",
                                   value: self.$viewModel.windDirection,
                                   backgroundColor: .red)
                    PredictionRow(title: "Precipitation",
                                   value: self.$viewModel.cloudCover,
                                   backgroundColor: .blue)
                    PredictionRow(title: "Pressure",
                                   value: self.$viewModel.pressure,
                                   backgroundColor: .purple)
                    PredictionRow(title: "Wind Speed",
                                   value: self.$viewModel.windSpeed,
                                   backgroundColor: .green)
                }
            }
            .padding(10)
        }
        .cornerRadius(15)
    }
}
