import SwiftUI 

public struct TemperatureRow: View {
    
    @Binding public var temp: Double
    
    public init(temp: Binding<Double>) {
        self._temp = temp 
    }
    
    public var body: some View {
        VStack {
            Text("Temperature")
                .foregroundColor(.white)
                .multilineTextAlignment(.leading)
                .font(.system(size: 18,
                              weight: .regular,
                              design: .rounded))
                .frame(maxWidth: .infinity,
                       alignment: .leading)
            
            HStack {
                Slider(value: $temp, in: 0...35, step: 1.0)
                    .accentColor(.white)
                Text("\($temp.wrappedValue)" + "°C")
                    .foregroundColor(.white)
                    .font(.system(size: 18,
                                  weight: .medium,
                                  design: .rounded))
            }
            .padding()
            .background(Color(UIColor.darkGray.withAlphaComponent(0.7)))
            .cornerRadius(6)
            .clipped()
        }
    }
}

public struct CloudCoverRow: View {
    
    @Binding public var cloudCover: CloudCover
    
    public init(cloudCover: Binding<CloudCover>) {
        self._cloudCover = cloudCover
        
        if self.cloudCover == .cloudy {
            
        }
    }
    
    public var body: some View {
        VStack {
            Text("Precipitation")
                .foregroundColor(.white)
                .multilineTextAlignment(.leading)
                .font(.system(size: 18,
                              weight: .regular,
                              design: .rounded))
                .frame(maxWidth: .infinity,
                       alignment: .leading)
            
            HStack(spacing: 15) {
                SystemImageButton(image: "cloud.fill",
                                  paddingImage: 19,
                                  isSelected: self.cloudCover == .cloudy ? true : false) {
                                    self.cloudCover = .cloudy
                }
                .frame(height: 65)
                
                SystemImageButton(image: "cloud.drizzle.fill",
                                  isSelected: self.cloudCover == .rain ? true : false) {
                                    self.cloudCover = .rain
                }
                .frame(height: 65)
                
                SystemImageButton(image: "cloud.bolt.rain.fill",
                                  isSelected: self.cloudCover == .storm ? true : false) {
                                    self.cloudCover = .storm
                }
                .frame(height: 65)
            }
        }
    }
}

public struct WindDirectionRow: View {
    
    @Binding public var wind: WindDirection
    
    public init(wind: Binding<WindDirection>) {
        self._wind = wind
    }
    
    public var body: some View {
        VStack {
            Text("Wind")
                .foregroundColor(.white)
                .multilineTextAlignment(.leading)
                .font(.system(size: 16,
                              weight: .regular,
                              design: .rounded))
                .frame(maxWidth: .infinity,
                       alignment: .leading)
            
            HStack(spacing: 15) {
                SystemImageButton(image: "arrow.up",
                                  paddingImage: 19,
                                  isSelected: self.wind == .north ? true : false) {
                                    self.wind = .north
                }
                .frame(height: 65)
                
                SystemImageButton(image: "arrow.left",
                                  paddingImage: 19,
                                  isSelected: self.wind == .south ? true : false) {
                                    self.wind = .south
                }
                .frame(height: 65)
                
                SystemImageButton(image: "arrow.right",
                                  paddingImage: 19,
                                  isSelected: self.wind == .west ? true : false) {
                                    self.wind = .west
                }
                .frame(height: 65)
                
                SystemImageButton(image: "arrow.down",
                                  paddingImage: 19,
                                  isSelected: self.wind == .east ? true : false) {
                                    self.wind = .east
                }
                .frame(height: 65)
            }
        }
    }
}

public struct HumidityRow: View {
    
    @Binding public var humidity: Humidity 
    
    public init(humidity: Binding<Humidity>) {
        self._humidity = humidity
    }
    
    public var body: some View {
        VStack {
            Text("Humidity")
                .foregroundColor(.white)
                .multilineTextAlignment(.leading)
                .font(.system(size: 16,
                              weight: .regular,
                              design: .rounded))
                .frame(maxWidth: .infinity,
                       alignment: .leading)
            HStack(spacing: 15) {
                HumidityButton(state: .min,
                               isSelected: self.humidity == .min ? true : false) {
                                self.humidity = .min
                }
                .frame(height: 65)
                
                HumidityButton(state: .normal,
                               isSelected: self.humidity == .normal ? true : false) {
                                self.humidity = .normal
                }
                .frame(height: 65)
                
                HumidityButton(state: .max,
                               isSelected: self.humidity == .max ? true : false) {
                                self.humidity = .max
                }
                .frame(height: 65)
            }
        }
    }
}
