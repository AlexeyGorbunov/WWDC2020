import Foundation
import Combine
import CoreML

public class PredictionModelInput: MLFeatureProvider {
    public var featureNames: Set<String>
    public var inputs: [String: Double] = .init()
    
    public init(featureNames: Set<String>, inputs: [String: Double]) {
        self.featureNames = featureNames
        self.inputs = inputs
    }
    
    public func featureValue(for featureName: String) -> MLFeatureValue? {
        guard let value = inputs[featureName] else { return nil }
        return MLFeatureValue(double: value)
    }
}

public class PredictionModelOutput: MLFeatureProvider {
    
    private let provider: MLFeatureProvider
    public var outputs: [String: Double] = .init()
    
    public var featureNames: Set<String> {
        self.provider.featureNames
    }
    
    public func featureValue(for featureName: String) -> MLFeatureValue? {
        self.provider.featureValue(for: featureName)
    }
    
    public init(feature: MLFeatureProvider) {
        self.provider = feature
        if let value = provider.featureValue(for: "temperature") {
            outputs["temperature"] = value.doubleValue 
        } else if let value = provider.featureValue(for: "cloudCover") {
            outputs["cloudCover"] = value.doubleValue 
        } else if let value = provider.featureValue(for: "pressure") {
            outputs["pressure"] = value.doubleValue
        } else if let value = provider.featureValue(for: "windBearing") {
            outputs["windBearing"] = value.doubleValue
        } else if let value = provider.featureValue(for: "windSpeed") {
            outputs["windSpeed"] = value.doubleValue
        }
    }
}

public class PredictionModel {
    
    private var model: MLModel
    private var url: URL
    
    public init(type: PredictionItemType) {
        switch type {
        case .temperature:
            self.url = #fileLiteral(resourceName: "WeatherTemperature.mlmodel")
        case .windDirection:
            self.url = #fileLiteral(resourceName: "WeatherWindDirection.mlmodel")
        case .cloudCover:
            self.url = #fileLiteral(resourceName: "WeatherCloudCover.mlmodel")
        case .pressure:
            self.url = #fileLiteral(resourceName: "WeatherPressure.mlmodel")
        case .windSpeed:
            self.url = #fileLiteral(resourceName: "WeatherWindSpeed.mlmodel")
        }
        
        let urlCompileModel = try! MLModel.compileModel(at: url)
        self.model = try! MLModel(contentsOf: urlCompileModel)
    }
    
    public func getModel() -> MLModel {
        return model 
    }
    
    func prediction(input: PredictionModelInput) throws -> PredictionModelOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }
    
    func prediction(input: PredictionModelInput,
                    options: MLPredictionOptions) throws -> PredictionModelOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return PredictionModelOutput(feature: outFeatures)
    }
    
    public func prediction(featureNames: Set<String>,
                           inputs: [String: Double]) throws -> PredictionModelOutput {
        let input = PredictionModelInput(featureNames: featureNames, inputs: inputs)
        return try self.prediction(input: input)
    }
}
