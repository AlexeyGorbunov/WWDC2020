import Foundation
import Combine 

public class ConfigurationViewModel: ObservableObject {
    
    @Published public var temperature: Double = 10.0
    @Published public var cloudCover: CloudCover = .cloudy
    @Published public var windDirection: WindDirection = .north
    @Published public var humidity: Humidity = .min
    
    let weatherManager = WeatherManager.shared
    var cancellable = Set<AnyCancellable>()
    
    public init() {
        
        $temperature
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { (value) in
                self.weatherManager.temperatureInput.send(value)
            }
            .store(in: &cancellable)
        
        $cloudCover
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { (value) in
                self.weatherManager.cloudCoverInput.send(value.rawValue)
            }
            .store(in: &cancellable)
        
        $windDirection
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { (value) in
                self.weatherManager.windDirectionInput.send(value.rawValue)
            }
            .store(in: &cancellable)
        
        $humidity
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { (value) in
                self.weatherManager.humidityInput.send(value.rawValue)
            }
            .store(in: &cancellable)
    }
}
