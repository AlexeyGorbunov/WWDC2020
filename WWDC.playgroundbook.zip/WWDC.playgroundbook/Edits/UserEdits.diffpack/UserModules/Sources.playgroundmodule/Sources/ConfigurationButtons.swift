
import SwiftUI

public struct SystemImageButton: View {
    
    public var isSelected: Bool
    public var image: String
    public var paddingImage: CGFloat
    public var action: (()->Void)
    
    public init(image: String,
                paddingImage: CGFloat = 15,
                isSelected: Bool,
                action: @escaping (()->Void)) { 
        self.image = image 
        self.paddingImage = paddingImage
        self.isSelected = isSelected
        self.action = action
    }
    
    public var body: some View {
        ZStack {
            Color(isSelected ? .white : UIColor.darkGray.withAlphaComponent(0.7))
                .cornerRadius(6)
            
            Button(action: {
                self.action()
            }, label: {
                Image(systemName: image)
                    .resizable()
                    .scaledToFit()
                    .font(Font.title.weight(.semibold))
                    .foregroundColor(isSelected ? .black : .white)
                    .padding(paddingImage)
            })
        }
    }
}

public struct HumidityButton: View {
    
    public enum State: CGFloat {
        case min = 40
        case normal = 25
        case max = 0
    }
    
    public var isSelected: Bool
    
    public var state: State
    public var action: (()->Void)
    
    public init(state: State,
                isSelected: Bool,
                action: @escaping (()->Void)) { 
        self.state = state
        self.isSelected = isSelected
        self.action = action
    }
    
    public var body: some View {
        ZStack {
            Color(isSelected ? .white : UIColor.darkGray.withAlphaComponent(0.7))
                .cornerRadius(6)
            
            Button(action: {
                self.action()
            }, label: {
                VStack { 
                    Spacer(minLength: state.rawValue)
                    Color.blue
                        .cornerRadius(6)
                }
                
            })
                .padding(8)
        }
    }
}



