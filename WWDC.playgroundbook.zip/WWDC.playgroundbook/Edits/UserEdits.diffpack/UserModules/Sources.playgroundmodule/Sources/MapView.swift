
import SwiftUI
import UIKit
import MapKit

public struct MapView: UIViewRepresentable {
    
    public init() { }
    
    var position: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: 59.939824,
                               longitude: 30.315774)
    }
    
    public func makeUIView(context: Context) -> MKMapView {
        let annotation = MKPointAnnotation()
        annotation.title = "Saint-Petersburg"
        annotation.coordinate = position
        
        let region = MKCoordinateRegion(center: position, latitudinalMeters: 16000, longitudinalMeters: 16000)
        
        let mapView = MKMapView()
        mapView.showsBuildings = true 
        mapView.setRegion(region, animated: true)
        mapView.addAnnotation(annotation)
        return mapView
    }
    
    public func updateUIView(_ uiView: MKMapView, context: Context) {
        
    }
}

